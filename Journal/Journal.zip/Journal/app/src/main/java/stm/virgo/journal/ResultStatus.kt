package stm.virgo.journal

class ResultStatus {
    val pesan: String? = null
    val status: Int? = null
}